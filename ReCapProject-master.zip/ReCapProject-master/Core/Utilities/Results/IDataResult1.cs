﻿namespace Core.Utilities.Results
{
    public interface IDataResult
    {
    }
}